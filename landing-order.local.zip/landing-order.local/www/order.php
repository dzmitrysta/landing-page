<!DOCTYPE html>
<html>
<head>
	<title>Спасибо!</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="Заказ на создание лендинга." />
	<meta name="keywords" content="заказ лендинга, создание лендинга" />
	<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" />
	<link type="text/css" rel="stylesheet" href="css/order.css" />
</head>
<body>
	<div>
		<h1>Спасибо!</h1>
		<p>Через несколько минут с Вами свяжется наш специалист.</p>
	</div>
</body>