<?php
require_once "lib/start.php";

unset($_SESSION["camp_id"]);
if (!isset($_SESSION["camp_id"]) || !$_SESSION["camp_id"]) {
  $data = array();
  $data["ip"] = ip2long($_SERVER["REMOTE_ADDR"]);
  $data["utm_source"] = isset($request["utm_source"])? $request["utm_source"] : null;
  $data["utm_campaign"] = isset($request["utm_campaign"])? $request["utm_campaign"] : null;
  $data["utm_content"] = isset($request["utm_content"])? $request["utm_content"] : null;
  $data["utm_term"] = isset($request["utm_term"])? $request["utm_term"] : null;
  $camp_id = getCampID($data);

 if (!$camp_id) {
    $data["ref"] = isset($_SERVER["HTTP_REFERER"])? $_SERVER["HTTP_REFERER"] : null;
    $data["date"] = time();
    $camp_id = addCamp($data);
  }
  $_SESSION["camp_id"] = $camp_id;
  echo $camp_id;
}

?>




<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Высококачественный лендинг под ключ, без предоплаты. Мы гарантируем продажи по всему миру!</title>
    <meta name="keywords" content="Лендинг,  SPLIT-тест, A/B-тестирование,  web-студия, бизнес, многоязычный, русский, польский, английский, немецкий, язык, разработка, создание, сайт, продажа, продажник, дешево, под ключ, гарантия">
    <meta name="description" content="Разработка высококачественных лендингов (Landing Page) под ключ. СЕО-продвижение (SEO) и расширенная поддержка. Гарантия продаж">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/style.css">
    <link type="text/css" rel="stylesheet" href="fancybox/jquery.fancybox.css" />
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.min.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <?php if($message){?>
      <script type="text/javascript">
          alert("<?=$message?>");
      </script>
  <?php } ?>

  <body data-spy="scroll" data-target="#myNavbar" data-offset="70">



  <!-- NAVBAR-->

   <div id="myNavbar" class="navbar navbar-default navbar-fixed-top" role="navigation">
     <div class="container">

       <div class="navbar-header">
         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target= ".navbar-collapse">
           <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
         </button>

         <a class="navbar-brand" href="#">LEPAGE.RU</a>

       </div>

       <div class="navbar-collapse collapse">
         <ul class="nav navbar-nav navbar-right">
           <li><a href="#about">Преимущества</a></li>
           <li><a href="#features">Порядок работы </a></li>
           <li><a href="#efficiency">Эффективность</a></li>
           <li><a href="#portfolio">Портфолио</a></li>
           <li><a href="#prices">Цены</a></li>
           <li><a href="#guarantee">Гарантия</a></li>
           <li><a href="#form">Подать заявку</a></li>
         </ul>
       </div>

     </div>
   </div>

  <!-- END OF NAVBAR-->


  <!-- HEADER-->


    <div class="header">
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-sm-12 col-xs-12 wow slideInLeft">
            <h1>Landing Page</h1>
            <p>Высококачественный лендинг под ключ, без предоплаты. Мы гарантируем продажи по всему миру!</p>
            <p><a href="#form" class="btn btn-primary btn-md">ПОЛУЧИТЬ КОНСУЛЬТАЦИЮ</a></p>
          </div>

          <div class="col-lg-6 col-sm-12 col-xs-12 wow slideInRight" align="center">
              <img class="img-responsive" src="img/devices.png" alt="Landing Page"/>
          </div>


        </div>
      </div>
    </div>


  <!-- END HEADER-->



  <!--ABOUT-->
    <div class="about" id="about">
      <div class="container">

        <div class="row">
          <div class="col-lg-12 col-md-12">
            <h1 class="wow fadeIn" data-wow-delay="0.4s">Преимущества сотрудничества с нами:</h1>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-4 wow fadeIn" data-wow-delay="0.1s">
              <img src="img/logo2.png" alt="Язык лэндинга: Русский, Английский, Немецкий или Польский">
              <blockquote><p>Вы можете выбрать язык лендинга: русский, английский, немецкий или польский</p></blockquote>
          </div>



          <div class="col-lg-4 col-md-4 col-sm-4 wow fadeIn" data-wow-delay="0.2s">
            <img src="img/logo1.png" alt="Лендинг (landing page) под ключ">
            <blockquote><p>Делаем всё под ключ, срок разработки - не более 14 дней</p></blockquote>
          </div>



          <div class="col-lg-4 col-md-4 col-sm-4 wow fadeIn" data-wow-delay="0.3s">
            <img src="img/logo3.png" alt="Наши лендинги полностью адаптивны">
            <blockquote><p>Наши лендинги высокого качества и полностью адаптивны, что является важным фактором успеха Вашего бизнеса</p></blockquote>
          </div>


          <div class="col-lg-4 col-md-4 col-sm-4 wow fadeIn" data-wow-delay="0.4s">
            <img src="img/logo4.png" alt="Cоздание рекламной кампании landing page в Яндекс.Директ или Google Adwords">
            <blockquote><p>Бесплатное создание рекламной кампании в Яндекс.Директ или Google Adwords (для сайтов, ориентированных на западную аудиторию)</p></blockquote>
          </div>



          <div class="col-lg-4 col-md-4 col-sm-4 wow fadeIn" data-wow-delay="0.5s">
            <img src="img/logo5.png" alt="SPLIT-тестирование лендинга">
            <blockquote><p>Проводим SPLIT-тестирование для достижения максимальной эффективности лендинга</p></blockquote>
          </div>


          <div class="col-lg-4 col-md-4 col-sm-4 wow fadeIn" data-wow-delay="0.6s">
            <img src="img/logo6.png" alt="Мы не берем предоплату за landing page">
            <blockquote><p>В отличие от большинства WEB-студий, мы не берем предоплату!</p></blockquote>
          </div>
        </div>


        <div class="row">

          <div class="col-lg-12 col-sm-12 col-xs-12 wow bounce">
           <p><a href="#form" class="btn btn-primary btn-md">ПОЛУЧИТЬ КОНСУЛЬТАЦИЮ</a></p>
          </div>
        </div>


      </div>
    </div>


  <!--END OF ABOUT-->


  <!-- FEATURES -->

  <div class="features" id="features">
    <div class="container">

      <div class="row">
        <div class="col-lg-12 col-md-12">
          <h1>ПОРЯДОК РАБОТЫ</h1>
          <p><em>Работать с нами так же легко, как общаться с другом...</em></p>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-4 col-md-4 wow bounceInLeft">
          <i class="fa fa-user fa-3x" aria-hidden="true"></i>
          <h4>Заявка </h4>
          <p>Вы оставляете заявку на создание лендинга.</p>

          <i class="fa fa-phone-square fa-3x" aria-hidden="true"></i>
          <h4>Обсуждение проекта </h4>
          <p>Мы созваниваемся с Вами и консультируем Вас, опираясь на специфику Вашего бизнеса.</p>

          <i class="fa fa-pencil-square fa-3x" aria-hidden="true"></i>
          <h4>Дизайн</h4>
          <p>Мы готовим прототип, в который Вы можете вносить коррективы на любом этапе. Наполняем сайт контентом, направленым на максимизацию Вашей прибыли.</p>
        </div>

        <div class="col-lg-4 col-md-4 wow fadeIn" data-wow-delay="0.3s" align="center">
          <img class="img-responsive" src="img/screenshots/iphonescreen.png"/>
        </div>

        <div class="col-lg-4 col-md-4 wow bounceInRight">
          <i class="fa fa-magic fa-3x" aria-hidden="true"></i>
          <h4>Веб-разработка </h4>
          <p>Мы создаем лендинг, запускаем рекламу и получаем Вам первых клиентов.</p>

          <i class="fa fa-credit-card-alt fa-3x" aria-hidden="true"></i>
          <h4>Оплата</h4>
          <p>Вы оплачиваете стоимость лендинга, а мы присылаем все исходники, даём доступ к уже работающей рекламной кампании и к клиентам.</p>

          <i class="fa fa-handshake-o fa-3x" aria-hidden="true"></i>
          <h4>Поддержка</h4>
          <p>После разработки лендинга, мы остаемся с Вами и дарим до 3 месяцев сопровождения проекта, помогаем развивать Ваш бизнес.</p>
        </div>

      </div>

    </div>
  </div>

  <!-- END FEATURES -->


  <!--efficiency-->

  <div class="efficiency" id="efficiency">
    <div class="container">

      <div class="row">
        <div class="col-lg-12 col-md-12">
          <h1 class="wow fadeIn" data-wow-delay="0.4s">ПОЧЕМУ НАШИ ЛЕНДИНГИ ЭФФЕКТИВНЫ?</h1>

        </div>
      </div>

      <div class="row">
        <div class="col-lg-5 col-md-5 wow bounceInRight">
         <div class="efficiency-row1"> <i class="fa fa-leaf fa-3x" aria-hidden="true"></i>
          <h4>Оптимизация</h4>
          <p>Все наши лендинги оптимизированы под мобильные устройства.</p>

          <i class="fa fa-cogs fa-3x" aria-hidden="true"></i>
          <h4>Технологичность</h4>
          <p>Мы используем новейшие технологии Web-дизайна. Это поможет Вашему лендингу выглядеть более красивым и современным, что, безусловно, положительно скажется на конверсии.</p>

          <i class="fa fa-line-chart fa-3x" aria-hidden="true"></i>
           <h4>Анализ запросов </h4>
           <p>Оптимизация рекламной кампании. Сюда входит анализ каждого ключевого запроса: удаление неэффективных, снижение цен на слабоэффективных и повышение цен на высокоэффективные с целью повышение числа клиентов. В результате, Вы гарантированно получаете максимальное число заявок при минимальной её стоимости.</p>

        </div></div>

        <div class="col-lg-2 col-md-2 hidden-sm hidden-xs" align="center">
          <img class="img-responsive" src="img/screenshots/tree.png"/>
        </div>

        <div class="col-lg-5 col-md-5 wow bounceInLeft">
          <div class="efficiency-row2">  <i class="fa fa-coffee fa-3x" aria-hidden="true"></i>
            <h4>Удобство</h4>
            <p>Оповещение о заявках по SMS. По Вашему желанию можно сделать так – после получения заявки Вам отправляется SMS с номером телефона клиента. И Вы сразу сможете позвонить ему. Клиент будет приятно шокирован от Вашей скорости!</p>

            <i class="fa fa-usd fa-3x" aria-hidden="true"></i>
          <h4>Конверсия</h4>
          <p>По Вашему желанию мы бесплатно проводим SPLIT-тесты! Например, берётся одна цена и изменяется в сторону увеличения.
            Дальше половина клиентов видит новую цену, а другая половина – старую. Часто случается, что при увеличении цены на 50%, число заявок уменьшается лишь
            на 10% или не изменяется вовсе.
            У нас были случаи, когда количество продаж увеличивалось. Ваша прибыль будет расти!</p>

          <i class="fa fa-thumbs-o-up fa-3x" aria-hidden="true"></i>
          <h4>Бесплатная SEO оптимизация </h4>
          <p>Наша цель – максимально поднять прибыльность Вашего бизнеса и мы сделаем для этого все возможное.</p>
        </div></div>

      </div>

      <div class="row">

        <div class="col-lg-12 col-sm-12 col-xs-12 wow bounce">
          <p><a href="#form" class="btn btn-primary btn-md">ПОЛУЧИТЬ КОНСУЛЬТАЦИЮ</a></p>
        </div>
      </div>

    </div>
  </div>

  <!--end of efficiency-->

  <!-- SCREENSHOTS -->

  <div class="screenshots" id="portfolio">
    <div class="container">

      <div class="row">
        <div class="col-lg-12 col-md-12">

          <h1>НАШИ ПОСЛЕДНИЕ РАБОТЫ И НЕКОТОРЫЕ КЛИЕНТЫ</h1>
          <p>Вы можете заказать лэндинг на одном из четырех языков: Русском, Английском, Немецком или Польском...</p>

        </div>
      </div>

      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 wow flipInY" data-wow-delay="0.2s">

          <div class="work_block">
            <div class="image_wrap">
              <div class="work_descr">
                <h4><a href="img/screenshots/russian.jpg">РУССКИЙ ЯЗЫК</a></h4>
                <p>конверсия 9%</p>
              </div>
            </div>
            <img src="img/screenshots/russian_s.jpg" class="img-responsive" alt="РУССКИЙ ЯЗЫК">
          </div>

        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 wow flipInY" data-wow-delay="0.4s">

          <div class="work_block">
            <div class="image_wrap">
              <div class="work_descr">
                <h4><a href="img/screenshots/english.jpg">АНГЛИЙСКИЙ ЯЗЫК</a></h4>
                <p>конверсия 11%</p>
              </div>
            </div>
            <img src="img/screenshots/english_s.jpg" class="img-responsive" alt="АНГЛИЙСКИЙ ЯЗЫК">
          </div>

        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 wow flipInY" data-wow-delay="0.6s">

          <div class="work_block">
            <div class="image_wrap">
              <div class="work_descr">
                <h4><a href="img/screenshots/german.jpg">НЕМЕЦКИЙ ЯЗЫК</a></h4>
                <p>конверсия 7%</p>
              </div>
            </div>
            <img src="img/screenshots/german_s.jpg" class="img-responsive" alt="НЕМЕЦКИЙ ЯЗЫК">
          </div>

        </div>

        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 wow flipInY" data-wow-delay="0.8s">

          <div class="work_block">
            <div class="image_wrap">
              <div class="work_descr">
                <h4><a href="img/screenshots/polski.jpg">ПОЛЬСКИЙ ЯЗЫК</a></h4>
                <p>конверсия 8%</p>
              </div>
            </div>
            <img src="img/screenshots/polski_s.jpg" class="img-responsive" alt="ПОЛЬСКИЙ ЯЗЫК">
          </div>


        </div>
      </div>

    </div>
  </div>

  <!-- END SCREENSHOTS -->

  <!-- sponsors -->
  <section id="sponsors">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-xs-6">
          <img src="img/logos/kickstarter.png" alt="sponsor" class="wow rotateIn">
        </div>
        <div class="col-md-3 col-xs-6">
          <img src="img/logos/techradar.png" alt="sponsor" class="wow rotateIn" data-wow-delay=".5s">
        </div>
        <div class="col-md-3 col-xs-6">
          <img src="img/logos/telegraph.png" alt="sponsor" class="wow rotateIn" data-wow-delay="1s">
        </div>
        <div class="col-md-3 col-xs-6">
          <img src="img/logos/verge.png" alt="sponsor" class="wow rotateIn" data-wow-delay="1.5s">
        </div>
      </div>
    </div>
  </section>

  <!-- end of sponsors -->


  <!--Prices-->
  <div class="prices" id="prices">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">

          <h1>НАШИ ЦЕНЫ ВАС ПРИЯТНО УДИВЯТ</h1>


        </div>
      </div>

      <div class="row">

        <div class="col-md-4 col-sm-12">
          <div class="serviceBox wow fadeIn" data-wow-delay="0.3s">
            <div class="service-icon">
              <i class="fa fa-rocket"></i>
            </div>
            <div class="service-content">
              <h3 class="title">СТАРТ</h3>
               <p class="description">
                 Анализ Вашей ниши<br>
                 Аудит сайта<br>
                 Анализ конкурентов и их активности<br>
                 Консультация<br>
                 Цена пакета "Старт" будет<br>
                 вычтена из будущего заказа
              </p>
            </div>
            <a href="#form" class="read">590 rub или 10 USD</a>
          </div>
        </div>

        <div class="col-md-4 col-sm-12">
          <div class="serviceBox wow fadeIn" data-wow-delay="0.6s">
            <div class="service-icon">
              <i class="fa fa-briefcase"></i>
            </div>
            <div class="service-content">
              <h3 class="title">БИЗНЕС</h3>
              <p class="description">

                Маркетинговое исследование<br>
                Анализ кoнкурентов<br>
                Разработка продающего сайта<br>
                Разработка стратегии интернет-продаж<br>
                Запуск рекламной кампании Yandex Direct<br>
                SPLIT-тесты<br>
                Техническая поддержка<br>
                SEO-подготовка<br>
                Инструменты для повышения конверсии
              </p>
            </div>
            <a href="#form" class="read">14 800 RUB или 250 USD</a>
          </div>
        </div>

        <div class="col-md-4 col-sm-12">
          <div class="serviceBox wow fadeIn" data-wow-delay="0.9s">
            <div class="service-icon">
              <i class="fa fa-globe"></i>
            </div>
            <div class="service-content">
              <h3 class="title">БИЗНЕС МИР</h3>
              <p class="description">
                Английски, Немецкий, Польский языки<br>
                Маркетинговое исследование<br>
                Анализ кoнкурентов<br>
                Разработка продающего сайта<br>
                Разработка стратегии интернет-продаж<br>
                Запуск рекламной кампании в Google Adwords<br>
                SPLIT-тесты<br>
                Техническая поддержка<br>
                SEO-подготовка<br>
                Продвижение в Google<br>
                Инструменты для повышения конверсии
              </p>
            </div>
            <a href="#form" class="read">23 900 RUB или 400 USD</a>
          </div>
        </div>



      </div><!-- ./row -->
    </div><!-- ./container -->

  </div>
  <!-- End of Prices-->

  <!-- Guarantee-->
  <section id="guarantee">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-xs-12">
          <img src="img/guarantee.png" alt="guarantee">
        </div>
        <div class="col-md-8 col-xs-12 wow rotateIn" data-wow-delay=".5s">
          <p>Мы отвечаем за свою работу и гарантируем великолепное соотношение цена/ качество. Кроме того, мы не требуем никакой предоплаты, не требуем даже денег на рекламный бюджет. Мы делаем все сами, а потом показываем высококачественный  лендинг,  а также знакомим с результатами  SPLIT-тестов,  даем доступ к полностью настроенной и оптимизированной рекламной кампании и реальным клиентам! И уж поверьте,  наш огромный опыт  сделает свое дело - Вы останетесь довольны конечным результатом и готовым источником доходов! Но если Вам не понравится, то Вы свободно сможете отказаться от лендинга и не платить за него.
          </p>
          <p>Согласитесь, для Вашего бизнеса это очень заманчивое предложение, и Вы не рискуете потерять ни одного рубля!</p>
        </div>

      </div>

      <div class="row">

        <div class="col-lg-12 col-sm-12 col-xs-12">
          <a href="#form" class="btn btn-primary btn-md">ОФОРМИТЬ ЗАЯВКУ</a>
        </div>
      </div>

    </div>
  </section>

  <!-- End of Guarantee-->

  <!--Call Me-->

  <section id="form">
    <div class="container text-center wow fadeInDown">
      <div class="row">
        <h1>МЫ СВЯЖЕМСЯ С ВАМИ ЧЕРЕЗ НЕСКОЛЬКО МИНУТ</h1>
        <p>Вы можете указать любой спооб связи (телефон, Email)<br>а также, по желанию, указать интересующий Вас тарифный план</p>
      </div>
      <div class="row">
        <div class="col-md-10 col-md-offset-1">
          <div class="section-form wow zoomIn">
            <form id="myForm" name="order" action="#" method="post">
              <div class="row">
                <div class="form-group col-md-3">
                  <input type="text" class="form-control rfield"  name="phone" placeholder="Телефон">
                  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                </div>
                <div class="form-group col-md-3">
                  <input type="email" class="form-control rfield" name="email" placeholder="Адрес Email">
                  <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                </div>
                <div class="form-group col-md-3">
                  <select name="plan" class="form-control form-sel" style="width: 100%; height: 44px;">
                    <option disabled selected class="hidden">Выберите план</option>
                    <option value="1"><p>СТАРТ</p></option>
                    <option value="2"><p>БИЗНЕС</p></option>
                    <option value="3"><p>БИЗНЕС МИР</p></option>
                  </select>
                </div>
                <button type="submit" name="order" class="btn btn-primary btn-md btn_submit 1disabled">ГОТОВО!&ensp;<i class="fa fa-chevron-circle-right"></i></button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- End of Call Me-->

  <!-- FOOTER -->

  <div class="footer">
    <div class="container">

      <div class="row">

        <div class="col-lg-4 col-md-4">
          <h1>LEPAGE.RU</h1>
          <p>Since 2015</p>
          <p><em>'Мы делаем лендинги. Они должны быть лучшими.'</em></p>
        </div>

        <div class="col-lg-4 col-md-4">
          <h1>КОНТАКТЫ:</h1>
          <p><i class="fa fa-phone"></i>+7 (495) 104-45-54</p>
          <p><i class="fa fa-envelope-o"></i> <a href="mailto:dmit.saschin@yandex.ru">dmit.saschin@yandex.ru</a></p>
        </div>

        <div class="col-lg-4 col-md-4">
          <h1>О НАС:</h1>
          <p>Профессиональная команда WEB-разработчиков.</p>
          <p>LEPAGE &copy; 2015</p>
        </div>

      </div>

    </div>
  </div>

  <!-- END FOOTER -->

       <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

  <script src="js/wow.min.js"></script>

  <script>
    new WOW().init();
  </script>
  <script type="text/javascript" src="fancybox/jquery.fancybox.pack.js"></script>
    <script type="text/javascript" src="js/functions.js"></script>

  </body>
</html>