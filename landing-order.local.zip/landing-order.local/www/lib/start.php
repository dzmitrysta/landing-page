<?php

	mb_internal_encoding("UTF-8");
	error_reporting(E_ALL);
	ini_set("display_errors", 1);
	session_start();
	
	$message = false;
	define("SECRET", "prtdf123hjke");
	define("ADM_LOGIN", "admin");
	define("ADM_PASSWORD", "d441bf250b651d1afef44b5fd26380a9");
	
	define("DB_HOST", "localhost");
	define("DB_USER", "u0307465_root1");
	define("DB_PASSWORD", "h1ONY7pO");
	define("DB_NAME", "u0307465_lepage_landing_order");
	
	define("SMS_USER", "");
	define("SMS_PASSWORD", md5(""));
	define("SMS_PHONE", "");
	
	define("DIRECT_TOKEN", "");
	
	define("FORMAT_DATE", "Y.m.d H:i:s");

require_once "/var/www/u0307465/data/www/lepage.ru/lib/functions.php";
require_once "/var/www/u0307465/data/www/lepage.ru/lib/request.php";
	/*require_once "/home/landing-order.local/www/lib/functions.php";
	require_once "/home/landing-order.local/www/lib/request.php";*/
?>